context("create_alpha_param")

test_that("use", {

  testthat::expect_silent(
    create_alpha_param()
  )

})
