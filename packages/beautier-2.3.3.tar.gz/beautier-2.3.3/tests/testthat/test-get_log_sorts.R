test_that("use", {
  expect_silent(get_log_sorts())
})
