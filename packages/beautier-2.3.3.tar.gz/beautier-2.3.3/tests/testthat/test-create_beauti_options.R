context("create_beauti_options")

test_that("use", {

  testthat::expect_silent(create_beauti_options())
})
