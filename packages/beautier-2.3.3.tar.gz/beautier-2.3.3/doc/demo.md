# Demo

See [the 'Demo' vignette](https://github.com/ropensci/beautier/blob/master/vignettes/demo.Rmd).


