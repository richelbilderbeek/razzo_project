# Examples

See [the 'Examples' vignette](https://github.com/ropensci/beautier/blob/master/vignettes/examples.Rmd).

