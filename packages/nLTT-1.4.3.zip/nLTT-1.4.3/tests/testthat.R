library(testthat)
library(nLTT) # nolint keep package name non-all-lowercase, due to backwards compatibility

test_check("nLTT")
