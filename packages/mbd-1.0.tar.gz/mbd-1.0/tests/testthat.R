library(testthat)
library(mbd)

test_check("mbd")
