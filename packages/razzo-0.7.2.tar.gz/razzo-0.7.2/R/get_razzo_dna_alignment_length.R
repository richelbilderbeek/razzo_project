#' Get the razzo DNA alignment length, as used in the article
#' @export
get_razzo_dna_alignment_length <- function() {
  1000
}
