library(testthat)
library(razzo)

test_check("razzo")
