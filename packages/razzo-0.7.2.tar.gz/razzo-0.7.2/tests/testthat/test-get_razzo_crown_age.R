test_that("matches article", {
  expect_equal(get_razzo_crown_age(), 8.0)
})
