# News

Newest versions at top.

## peregrine 1.0 (2020-01-06)

### NEW FEATURES

  * First mature version
  
### MINOR IMPROVEMENTS

  * None

### BUG FIXES

  * None

### DEPRECATED AND DEFUNCT

  * None

