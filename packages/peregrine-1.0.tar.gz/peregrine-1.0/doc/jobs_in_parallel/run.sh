#!/bin/bash
sbatch job1_master.sh
