# job_without_rep

To run `job_without_rep` on the cluster nodes, use:

```
./run
```

This will put `job_without_rep` in the queue.

`job_without_rep` will display a random number on screen.
On Peregrine, this output will be written to a log file.
In `job_without_rep` the filename of this log
is set to `my.log`.