#!/bin/bash
sbatch simple_job.sh