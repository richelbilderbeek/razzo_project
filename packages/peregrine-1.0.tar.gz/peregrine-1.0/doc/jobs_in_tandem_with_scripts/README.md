# jobs_in_tandem

Goal of this is to create a pipeline:

```
job_1.sh -> job_2.sh -> job_3.sh
```

This can be done by submitting all jobs and adding a dependency.

All jobs are started with:

```
jobs.sh
```