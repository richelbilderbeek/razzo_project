#!/bin/bash
rm toy_example_1_1_1_1.trees
rm example.xml.state
rm toy_example_1_1_1_1.log
