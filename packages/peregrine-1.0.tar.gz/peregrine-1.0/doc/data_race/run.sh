#!/bin/bash
echo "START" > out.txt
sleep 1
sbatch add_a.sh

