#' pirouette: A package to estimate the error BEAST2
#' makes in inferring a phylogeny.
#'
#' 'pirouette' is an R package that estimates the error BEAST2 makes
#' from a given phylogeny. This phylogeny can be created using any (non-BEAST)
#' speciation model, for example the Protracted Birth-Death
#' or Multiple-Birth-Death models. 'pirouette' is presented in the article
#' (in press) "pirouette: the error BEAST2 makes in inferring a phylogeny"
#' authored by R. J. C. Bilderbeek, G. Laudanno and R. S. Etienne.
#'
#' @examples
#' library(testthat)
#'
#' phylogeny <- ape::read.tree(text = "(((A:1, B:1):1, C:2):1, D:3);")
#'
#' # Select all experiments with 'run_if' is 'always'
#' experiment <- create_test_gen_experiment()
#' experiments <- list(experiment)
#'
#' pir_params <- create_pir_params(
#'   alignment_params = create_test_alignment_params(),
#'   experiments = experiments
#' )
#'
#' errors <- NA
#' if (rappdirs::app_dir()$os != "win" &&
#'   is_on_ci() && is_beast2_installed()
#' ) {
#'   errors <- pir_run(
#'     phylogeny = phylogeny,
#'     pir_params = pir_params
#'   )
#' } else {
#'   errors <- create_test_pir_run_output()
#' }
#'
#' # Return value
#' expect_true("tree" %in% names(errors))
#' expect_true(is.factor(errors$tree))
#' expect_true("true" %in% errors$tree)
#'
#' expect_true("inference_model" %in% names(errors))
#' expect_true(is.factor(errors$inference_model))
#' expect_true("generative" %in% errors$inference_model)
#'
#' expect_true("inference_model_weight" %in% names(errors))
#' expect_true(!is.factor(errors$inference_model_weight))
#'
#' expect_true("site_model" %in% names(errors))
#' expect_true(is.factor(errors$site_model))
#' expect_true("JC69" %in% errors$site_model)
#'
#' expect_true("clock_model" %in% names(errors))
#' expect_true(is.factor(errors$clock_model))
#' expect_true("strict" %in% errors$clock_model
#'   || "relaxed_log_normal" %in% errors$clock_model
#' )
#'
#' expect_true("tree_prior" %in% names(errors))
#' expect_true(is.factor(errors$tree_prior))
#' expect_true("birth_death" %in% errors$tree_prior ||
#'   "yule" %in% errors$tree_prior
#' )
#'
#' expect_true("error_1" %in% names(errors))
#' expect_true(!is.factor(errors$error_1))
#'
#' # Errors more than zero
#' col_first_error <- which(colnames(errors) == "error_1")
#' col_last_error <- ncol(errors)
#' expect_true(all(errors[, col_first_error:col_last_error] > 0.0))
#' n_errors <- col_last_error - col_first_error + 1
#' expect_true(n_errors < 11) # due to burn-in
#'
#' @note
#'   These abbeviations are commonly used throughout the package:
#'   \itemize{
#'     \item `nsm` Nucleotide Substitution Model
#'     \item `tral`: TRue ALignment
#'     \item `trtr`: TRue TRee
#'     \item `twal`: TWin ALignment
#'     \item `twtr`: TWin TRee
#'   }
#'
#' @seealso
#'
#' \itemize{
#'   \item To simulate an alignment, use \link{sim_alignment_with_std_nsm}
#'     or \link{sim_alignment_with_n_mutations}.
#'   \item To simulate a true alignment, see \link{check_sim_tral_fun}
#'     for an overview of functions.
#'   \item To simulate a twin alignment, see \link{check_sim_twal_fun}
#'     for an overview of functions.
#'   \item To simulate a twin tree, see \link{check_sim_twin_tree_fun}
#'     for an overview of functions.
#' }
#'
#'
#' These are packages associated with \link{pirouette}:
#' \itemize{
#'   \item{
#'     \link{babette}: work with BEAST2
#'   }
#'   \item{
#'     \link{beautier}: create BEAST2 input files
#'   }
#'   \item{
#'     \link{beastier}: run BEAST2
#'   }
#'   \item{
#'     \link{mauricer}: install BEAST2 packages
#'   }
#'   \item{
#'     \code{mcbette}: compare inference models
#'   }
#'   \item{
#'     \link{tracerer}: parse and analyse BEAST2 output
#'   }
#' }
#' @docType package
#' @name pirouette
#' @import beautier babette
NULL
