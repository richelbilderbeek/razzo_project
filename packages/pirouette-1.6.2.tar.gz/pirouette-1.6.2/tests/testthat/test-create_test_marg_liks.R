context("test-create_test_marg_liks")

test_that("use", {
  expect_silent(create_test_marg_liks())
})
