library(testthat)
library(pirouette)

test_check("pirouette")
