# Install the mcbett develop branch 
remotes::install_github("richelbilderbeek/mcbette", ref = "develop")