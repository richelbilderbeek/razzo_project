# `scripts`

Filename|Description
---|---
`install_pirouette`|Installs `pirouette` and all dependencies
