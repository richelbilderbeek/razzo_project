# Examples

```
No examples yet
```

For all examples, do load `pirouette`:

```{r}
library(pirouette)
```

