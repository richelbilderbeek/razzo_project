test_that("package style", {
  lintr::expect_lint_free()
})
