test_that("use", {
  alignment <- sim_twal_with_uns_nsm(
    twin_phylogeny = ape::read.tree(text = "((A:1, B:1):1, C:2);"),
    root_sequence = "aaaa"
  )
  expect_silent(check_alignment(alignment))
})
