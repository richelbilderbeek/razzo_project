library(testthat)
library(mbd.SimTrees)

test_check("mbd.SimTrees")
