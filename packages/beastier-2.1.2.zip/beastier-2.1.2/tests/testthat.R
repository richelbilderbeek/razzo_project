library(testthat)
library(beastier)

test_check("beastier")
