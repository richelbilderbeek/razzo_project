test_that("use", {
  expect_silent(get_java_version())
})
