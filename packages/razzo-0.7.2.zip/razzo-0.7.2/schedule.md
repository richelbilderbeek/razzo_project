# Schedule

Schedule for runs.

Issue                                                      |Description                                                     |Phase
-----------------------------------------------------------|----------------------------------------------------------------|-------
[371](https://github.com/richelbilderbeek/razzo/issues/371)|Test                                                            |Running
[346](https://github.com/richelbilderbeek/razzo/issues/346)|Giappo params, crown age 8, 2 replicates, 10x MCMC chain length |.
[367](https://github.com/richelbilderbeek/razzo/issues/367)|Full run with Giappo params                                     |.
[347](https://github.com/richelbilderbeek/razzo/issues/347)|Giappo run with more qs                                         |.
[324](https://github.com/richelbilderbeek/razzo/issues/324)|Establish the maximum number of tips we can take                |.
[294](https://github.com/richelbilderbeek/razzo/issues/294)|Check different epsilons in Nested MCMC runs                    |.




