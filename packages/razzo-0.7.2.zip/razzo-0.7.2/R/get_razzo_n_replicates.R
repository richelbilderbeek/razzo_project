#' Specify the number of replicates
#' @export
get_razzo_n_replicates <- function() {
  2
}
