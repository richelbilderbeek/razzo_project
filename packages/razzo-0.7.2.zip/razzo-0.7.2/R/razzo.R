#' razzo: the effect of MBD on inference
#'
#' @docType package
#' @name razzo
#' @import beautier beastier pirouette peregrine
NULL
