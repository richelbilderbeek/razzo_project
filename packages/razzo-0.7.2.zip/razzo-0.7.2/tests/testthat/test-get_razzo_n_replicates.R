test_that("matches article", {
  expect_equal(get_razzo_n_replicates(), 2)
})
