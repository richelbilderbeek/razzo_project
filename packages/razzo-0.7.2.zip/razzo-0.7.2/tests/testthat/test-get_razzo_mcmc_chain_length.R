test_that("matches article", {
  expect_equal(
    1e6,
    get_razzo_mcmc_chain_length()
  )
})
