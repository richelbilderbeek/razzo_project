test_that("matches article", {

  expect_equal(get_razzo_nus(), c(0.0, 0.5, 1.0, 1.5))
})
