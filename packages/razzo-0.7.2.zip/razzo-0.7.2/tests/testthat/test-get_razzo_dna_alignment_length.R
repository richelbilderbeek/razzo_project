test_that("marches article", {
  expect_equal(get_razzo_dna_alignment_length(), 1000)
})
