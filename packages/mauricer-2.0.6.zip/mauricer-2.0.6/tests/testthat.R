library(testthat)
library(mauricer)

test_check("mauricer")
