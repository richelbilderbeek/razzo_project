test_that("use", {
  expect_silent(is_beast2_ns_pkg_installed())
})
