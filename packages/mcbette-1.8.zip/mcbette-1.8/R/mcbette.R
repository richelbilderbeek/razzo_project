#' mcbette: Model Comparison Using Babette
#'
#' 'mcbette' does a model comparing using `babette`.
#'
#' @docType package
#' @name mcbette
#' @import beautier tracerer beastier mauricer babette
NULL
