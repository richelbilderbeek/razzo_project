library(testthat)
library(mcbette)

test_check("mcbette")
