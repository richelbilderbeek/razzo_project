#' Get the possible log sorts
#' @export
get_log_sorts <- function() {
  c(
    "alphabetic",
    "none",
    "smart"
  )
}
