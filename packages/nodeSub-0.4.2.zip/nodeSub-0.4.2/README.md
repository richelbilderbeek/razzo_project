# nodeSub
[![CRAN_Status_Badge](http://www.r-pkg.org/badges/version/GenomeAdmixR)](https://cran.r-project.org/package=nodeSub)

Branch|[![Travis CI logo](pics/TravisCI.png)](https://travis-ci.org)|[![AppVeyor logo](pics/AppVeyor.png)](https://www.appveyor.com)|[![Codecov logo](pics/Codecov.png)](https://www.codecov.io)
---|---|---|---
master|[![Build Status](https://travis-ci.org/thijsjanzen/nodeSub.svg?branch=master)](https://travis-ci.org/thijsjanzen/nodeSub)|[![Build status](https://ci.appveyor.com/api/projects/status/uhmo7nou1bltuamd?svg=true)](https://ci.appveyor.com/project/thijsjanzen/nodesub)|[![codecov.io](https://codecov.io/gh/thijsjanzen/nodeSub/branch/master/graph/badge.svg)](https://codecov.io/gh/thijsjanzen/nodeSub)
