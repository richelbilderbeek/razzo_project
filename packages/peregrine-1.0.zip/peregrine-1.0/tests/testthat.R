library(testthat)
library(peregrine)

test_check("peregrine")
