test_that("use", {
  expect_equal(2 * 2, 4)
})
