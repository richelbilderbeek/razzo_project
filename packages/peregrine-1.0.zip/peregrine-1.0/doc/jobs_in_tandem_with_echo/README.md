# jobs_in_tandem

Goal of this is to create a pipeline, by echoing
sbatch scripts sequentially.

The jobs are started with:

```
jobs.sh
```