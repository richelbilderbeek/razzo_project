# beast2_on_peregrine

How to get BEAST2 running with more cores on Peregrine?
