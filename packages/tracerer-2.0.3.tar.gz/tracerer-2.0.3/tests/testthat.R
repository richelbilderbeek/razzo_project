library(testthat)
library(tracerer)

test_check("tracerer")
